(function () {
  if (window.__MADHUSHALA_EXTENSION_BRIDGE__) return;
  window.__MADHUSHALA_EXTENSION_BRIDGE__ = true;

  const isExcisePortal = window.location.hostname === "excise.wb.gov.in";

  function text(row, selector) {
    return (row.querySelector(selector)?.textContent || "").trim();
  }

  function value(row, selector) {
    return (row.querySelector(selector)?.value || "").trim();
  }

  function typedCaseQuantity(row) {
    const raw = value(row, 'input[id$="_Qty"]');
    const quantity = Number.parseInt(raw, 10);
    return Number.isFinite(quantity) ? quantity : 0;
  }

  function selectedRows() {
    return Array.from(document.querySelectorAll('input[id$="_Qty"]'))
      .map((input) => input.closest("tr"))
      .filter(Boolean)
      .filter((row) => typedCaseQuantity(row) > 0)
      .map((row) => ({
        brand: text(row, '[id$="_glbl_brandvt"]'),
        strengthRaw: text(row, '[id$="_mlbllegStr"]'),
        measureMl: text(row, '[id$="_lblmsr"]'),
        packageType: text(row, '[id$="_lblbottle"]'),
        retailerMargin: text(row, '[id$="_lblrm"]'),
        roundOffGovt: text(row, '[id$="_lbl_Round_Off_Govt3"]'),
        specialPurposeFee: text(row, '[id$="_lbl_Special_Levy3"]'),
        mrpPerUnit: text(row, '[id$="_Label55"]'),
        bottlesPerCase: text(row, '[id$="_lblnobotpercase"]'),
        mrpPerCase: text(row, '[id$="_lblmrppercase"]'),
        supplier: text(row, '[id$="_lblsupplier"]'),
        warehouseCasesRaw: text(row, '[id$="_lblclblcase"]'),
        warehouseBottles: text(row, '[id$="_lblclosbal"]'),
        requestedCases: value(row, 'input[id$="_Qty"]'),
        requestedBottles: value(row, 'input[id$="_txt_bot"]'),
      }));
  }

  function toast(message, isError = false) {
    const node = document.createElement("div");
    node.textContent = message;
    node.style.cssText = [
      "position:fixed",
      "right:16px",
      "bottom:16px",
      "z-index:2147483647",
      "max-width:320px",
      "padding:10px 14px",
      "border-radius:6px",
      "font:13px/1.4 Arial,sans-serif",
      "box-shadow:0 8px 24px rgba(0,0,0,.22)",
      `background:${isError ? "#8f1d1d" : "#173f2f"}`,
      "color:#fff",
    ].join(";");
    document.documentElement.appendChild(node);
    setTimeout(() => node.remove(), 4500);
  }

  let captureTimer = null;
  let lastSuccessfulCaptureSignature = "";
  let pendingCaptureSignature = "";

  function captureSignature(items) {
    return items
      .map((item) => [
        item.brand,
        item.measureMl,
        item.packageType,
        item.requestedCases,
        item.requestedBottles,
      ].map((value) => String(value || "").trim().toLowerCase()).join("|"))
      .sort()
      .join("||");
  }

  async function capture(reason) {
    const items = selectedRows();
    if (!items.length) return;
    const signature = captureSignature(items);
    if (signature === lastSuccessfulCaptureSignature || signature === pendingCaptureSignature) return;
    pendingCaptureSignature = signature;
    try {
      const response = await chrome.runtime.sendMessage({
        source: "madhushala-excise-page",
        type: "AUTO_CAPTURE",
        payload: {
          reason,
          items,
          pageUrl: window.location.href,
          capturedAt: new Date().toISOString(),
        },
      });
      if (!response?.ok) throw new Error(response?.error || "Capture failed");
      lastSuccessfulCaptureSignature = signature;
      const result = response.result || {};
      const unmapped = result.mappingStatus?.unmappedCount || 0;
      toast(unmapped ? `${items.length} rows captured. ${unmapped} need mapping.` : `${items.length} rows captured. All mapped.`);
    } catch (error) {
      toast(error.message || "Capture failed", true);
    } finally {
      if (pendingCaptureSignature === signature) pendingCaptureSignature = "";
    }
  }

  function scheduleCapture(reason) {
    window.clearTimeout(captureTimer);
    captureTimer = window.setTimeout(() => capture(reason), 900);
  }

  if (isExcisePortal) {
    document.addEventListener("input", (event) => {
      if (event.target?.matches?.('input[id$="_Qty"], input[id$="_txt_bot"]')) {
        scheduleCapture("quantity_typed");
      }
    }, true);
    document.addEventListener("change", (event) => {
      if (event.target?.matches?.('input[id$="_Qty"], input[id$="_txt_bot"]')) {
        scheduleCapture("quantity_changed");
      }
    }, true);
    return;
  }

  window.postMessage({source: "madhushala-extension", type: "READY"}, window.location.origin);

  window.addEventListener("message", async (event) => {
    if (event.source !== window) return;
    const message = event.data || {};
    if (message.source !== "madhushala-web") return;
    if (message.type === "DISCOVER") {
      window.postMessage({source: "madhushala-extension", type: "READY"}, window.location.origin);
      return;
    }
    if (!message.requestId) return;

    try {
      const response = await chrome.runtime.sendMessage(message);
      window.postMessage({
        source: "madhushala-extension",
        requestId: message.requestId,
        ok: true,
        response,
      }, window.location.origin);
    } catch (error) {
      window.postMessage({
        source: "madhushala-extension",
        requestId: message.requestId,
        ok: false,
        error: error.message || "Extension request failed",
      }, window.location.origin);
    }
  });
})();
